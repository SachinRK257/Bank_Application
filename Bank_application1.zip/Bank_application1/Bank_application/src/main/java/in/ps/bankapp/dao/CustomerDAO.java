package in.ps.bankapp.dao;

import java.util.ArrayList;

import in.ps.bankapp.dto.Customer;

public interface CustomerDAO {
	public boolean insertCustomer(Customer c);
	public boolean udateCustomer(Customer c);
	public boolean deleteCustomer(int cid);
	public Customer getCustomer(String email,int pin);
	public ArrayList<Customer> getCustomer();
	public Customer getCustomer(String mail);
	public Customer getCustomer(int cid);
	

}
