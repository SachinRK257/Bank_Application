package in.ps.bankapp.dao;

import java.util.ArrayList;


import in.ps.bankapp.dto.Transaction;

public interface TransactionDAO {
	public boolean insertTransaction(Transaction t);
	public boolean updateTransaction(Transaction t);
	public boolean deleteTransaction(int id );
	public Transaction getTransaction(int id );
	public ArrayList<Transaction> getTransactionByCustomerId(long acc_no);
	public ArrayList<Transaction> getTransaction();

}
