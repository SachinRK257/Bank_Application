package in.ps.bankapp.dao;

import java.util.ArrayList;

import in.ps.bankapp.dto.Account;


public interface AccountDAO {
	public boolean insertAccount(Account a);
	public boolean udateAccount(Account a);
	public boolean deleteAccount(int acc_id);
	public Account getAccount(int acc_id);
	public Account getAccountByAccountNo(long acc_no);
	public ArrayList<Account> getAccount();
	public ArrayList<Account> getAccountByCustomerId(int cid);
//	public Account getAccountDetailsByCustomerId(int cid);

}
