package in.ps.bankapp.test;

import java.util.Scanner;

import in.ps.bankapp.dao.AccountDAO;
import in.ps.bankapp.dao.AccountsDaoImple;
import in.ps.bankapp.dao.CustomerDAO;
import in.ps.bankapp.dao.CustomerDaoImple;
import in.ps.bankapp.dto.Customer;

public class Password {
	public static void forgot() {
		CustomerDAO cdao=new CustomerDaoImple();
		AccountDAO acdao=new AccountsDaoImple();
		Scanner sc = new Scanner(System.in);
		System.out.println("eneter your mail:");
		String mail=sc.next();
		
		Customer c=cdao.getCustomer(mail);
		if(c!=null) {
			System.out.println("enter new Password:");
			int n_pass=sc.nextInt();
			System.out.println("confirm password:");
			int c_pass=sc.nextInt();
			if(n_pass==c_pass) {
				c.setPin(c_pass);
				boolean res=cdao.udateCustomer(c);
				if(res) {
					System.out.println("Password updated successfully");
				}
				else {
					System.out.println("Failed update Password");
				}
			}
			else {
				System.out.println("Password is not matched");
			}
			
			
			
			
		}
		else {
			System.out.println("customer does not exist");
		}
		
		
	}

}
