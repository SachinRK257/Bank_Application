package in.ps.bankapp.test;

import java.util.Scanner;

public class Test {
	public static String acc_type = null;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i = 0;
		System.out.println("Welcome to Bank Application");
do {
			System.out.println("1.Signup");

			System.out.println("2.Login");
			System.out.println("3/Forgot Pin");
			System.out.println("4.Exit");
			i = sc.nextInt();
			switch (i) {
			case 1:
				Signup.signup();
				break;
			case 2:
				Login.login();
	
				break;
			case 3:
				Password.forgot();
				break;
			case 4:
				System.out.println("Bank Application Terminated!");
				break;

			default:
				System.out.println("Invalid choice");
			}

		} while (i != 4);

	}

}
