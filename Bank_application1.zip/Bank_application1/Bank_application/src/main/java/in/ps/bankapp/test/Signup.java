package in.ps.bankapp.test;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import in.ps.bankapp.dao.AccountDAO;
import in.ps.bankapp.dao.AccountsDaoImple;
import in.ps.bankapp.dao.CustomerDAO;
import in.ps.bankapp.dao.CustomerDaoImple;
import in.ps.bankapp.dto.Account;
import in.ps.bankapp.dto.Customer;

public class Signup {
	public static void signup() {
		Scanner sc = new Scanner(System.in);
		CustomerDAO cdao = new CustomerDaoImple();
		AccountDAO adao = new AccountsDaoImple();
		System.out.println("Enter the type of the account, you would like to create");
		System.out.println("1.Savings");
		System.out.println("2.Current");
		System.out.println("3.Fd");
		System.out.println("4.Loan");

		String acc_type = null;
		int choice = 0;
		choice = sc.nextInt();

		while (acc_type == null) {
			switch (choice) {
			case 1:
				acc_type = "saving";
				break;
			case 2:
				acc_type = "current";
				break;
			case 3:
				acc_type = "fd";
				break;
			case 4:
				acc_type = "loan";
				break;
			default:
				System.out.println("Invalid choice");
			}

		}
		System.out.println(acc_type);
		Customer c = new Customer();
		System.out.println("Enter your First name:");
		c.setFname(sc.next());
		System.out.println("Enter your Last name:");
		c.setLname(sc.next());
		System.out.println("Enter your Phone number:");
		c.setPhone(sc.nextLong());
		System.out.println("Enter your Mail ID:");
		c.setMail(sc.next());
		Customer existing = Signup.checkExistingCustomer(c.getMail());
		if (existing != null) { // --> Already a user

			System.out.println("Your data already exists!");
			System.out.println("Please enter your PIN for further steps:");
			int existing_acc_pin = sc.nextInt();

			if (existing_acc_pin == existing.getPin()) {
				ArrayList<Account> existing_accounts = adao.getAccountByCustomerId(existing.getCid());

				if (existing_accounts != null && !existing_accounts.isEmpty()) {

					boolean accAlreadyExists = false;
					for (Account acc : existing_accounts) {
						String existing_type = acc.getAcc_type();
						System.out.println(acc.getAcc_no());
						System.out.println(existing_type);
						System.out.println("------------");
						if (acc_type.equalsIgnoreCase(existing_type)) {
							accAlreadyExists = true;

							break;
						}
					}
					if (accAlreadyExists) {
						System.out.println("Failed to create account as " + acc_type + " Account is already avaliable");
					} else {
						Signup.createAccount(c.getMail(), acc_type);
					}

				} else {
					System.out.println("No accounts found!");
					Signup.createAccount(c.getMail(), acc_type);

				}
			} else {
				System.out.println("Pin mismatch!");
			}
		} else { // New User

			System.out.println("Set your 4 DIGIT PIN:");
			int first_pin = sc.nextInt();
			System.out.println("Confirm the PIN:");
			int sec_pin = sc.nextInt();
			if (first_pin == sec_pin) {
				c.setPin(sec_pin);
				c.setStatus("Pending");
				boolean customer_res = cdao.insertCustomer(c);
				if (customer_res) {
					Signup.createAccount(c.getMail(), acc_type);
				} else {
					System.out.println("Failed to create an account");
				}

			} else {
				System.out.println("pin mismatch");
			}

		}

	}

	public static Customer checkExistingCustomer(String mail) {
		CustomerDAO cdao = new CustomerDaoImple();
		Customer c = cdao.getCustomer(mail);
		return c;

	}

	public static void createAccount(String mail, String acc_type) {
		Account a = new Account();
		AccountDAO adao = new AccountsDaoImple();
		Random r = new Random();
		long generated_no = r.nextLong(10000);
		a.setAcc_no(1100110000 + generated_no);
//		a.setCid(cid);
		a.setAcc_type(acc_type);
		a.setBalance(0);
		a.setStatus("Pending");
		Customer data = Signup.checkExistingCustomer(mail);
		a.setCid(data.getCid());
		boolean acc_res = adao.insertAccount(a);
		if (acc_res) {
			System.out.println("Account creation submitted, waiting for admin approval!");
		} else {
			System.out.println("Failed to create the account");
		}

	}

}
